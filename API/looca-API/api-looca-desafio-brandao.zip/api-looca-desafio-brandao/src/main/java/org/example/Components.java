package org.example;

public record Components(String nome, String unidadeMedida, int idComponente) {
    public Components {
    }
}
