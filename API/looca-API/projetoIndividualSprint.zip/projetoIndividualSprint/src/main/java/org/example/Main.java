package org.example;

import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.processador.Processador;
import com.github.britooo.looca.api.group.temperatura.Temperatura;
import org.springframework.jdbc.core.JdbcTemplate;

public class Main {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String CYAN_BOLD_BRIGHT = "\033[1;96m";  // CYAN


    public static void main(String[] args) {

        Conexao conexao = new Conexao();
        JdbcTemplate con = conexao.getConexaoDoBanco();

        con.execute("USE bankSecure;");

        Looca luquinhas = new Looca();

        System.out.println( CYAN_BOLD_BRIGHT+ "₊❏❜ ⋮LISTA DE INFORMAÇÕES - PROJETO INDIVIDUAL ⌒" + ANSI_RESET);

        System.out.println( CYAN_BOLD_BRIGHT + " ╰┈➤ INFORMAÇÔES DO PROCESSADOR: \n" + ANSI_RESET);
        Processador processador =  luquinhas.getProcessador();
        Temperatura temperatura = luquinhas.getTemperatura();

        Double temperaturaEscrita = temperatura.getTemperatura();
        double roundedUsoCPU = Math.round(processador.getUso());

        System.out.println("╭── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╮");
        System.out.println(CYAN_BOLD_BRIGHT + "Uso do procesador: " + roundedUsoCPU + " %" + ANSI_RESET );
        System.out.println(CYAN_BOLD_BRIGHT + "Temperatura:" + temperaturaEscrita + "°C" + ANSI_RESET);
        System.out.println("╰── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╯\n");

        String nome = "processador";
        String unidadeMedida = "Celsius e Porcentagem de Uso";

        con.update("INSERT INTO componente(nome, unidadeMedida, usoCPU, temperatura)VALUES (?,?,?,?)",
                nome,unidadeMedida,roundedUsoCPU ,temperaturaEscrita);

        System.out.println("Inserido no banco com sucesso!");

    }
}