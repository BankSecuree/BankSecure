package org.example;

import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.discos.Disco;
import com.github.britooo.looca.api.group.discos.DiscoGrupo;
import com.github.britooo.looca.api.group.memoria.Memoria;
import com.github.britooo.looca.api.group.processador.Processador;
import com.github.britooo.looca.api.group.rede.Rede;
import com.github.britooo.looca.api.group.sistema.Sistema;

import java.util.List;


public class Main {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_YELLOW = "\u001B[33m";


    public static void main(String[] args) {
        Looca luquinhas = new Looca();

        System.out.println( ANSI_YELLOW+ "₊❏❜ ⋮LISTA DE INFORMAÇÕES LOOCA ⌒" + ANSI_RESET);


        System.out.println( ANSI_YELLOW + " ★・・・・・・★ ★・・・・・・★ ★・・・・・・★ \n" + ANSI_RESET);

        System.out.println( ANSI_YELLOW + " ╰┈➤ INFORMAÇÕES DO SISTEMA: \n" + ANSI_RESET);
        Sistema sistema = luquinhas.getSistema();
        sistema.getPermissao();
        sistema.getFabricante();
        sistema.getArquitetura();
        sistema.getInicializado();
        sistema.getSistemaOperacional();
        sistema.getArquitetura();
        sistema.getTempoDeAtividade();
        System.out.println( "╭── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╮");
        System.out.println(sistema);
        System.out.println("╰── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╯\n");

        System.out.println( ANSI_YELLOW + " ╰┈➤ INFORMAÇÔES DO PROCESSADOR: \n" + ANSI_RESET);
        Processador processador =  luquinhas.getProcessador();
        processador.getFabricante();
        processador.getFrequencia();
        processador.getId();
        processador.getIdentificador();
        processador.getNumeroCpusFisicas();
        processador.getNumeroCpusLogicas();
        processador.getNumeroPacotesFisicos();
        processador.getMicroarquitetura();
        processador.getUso();
        processador.getNome();
        System.out.println("╭── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╮");
        System.out.println(processador);
        System.out.println("╰── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╯\n");


        System.out.println( ANSI_YELLOW + " ╰┈➤ INFORMAÇÕES DE MEMÓRIA : \n" + ANSI_RESET);

        Memoria memoria =  luquinhas.getMemoria();
        memoria.getDisponivel();
        memoria.getEmUso();
        memoria.getTotal();
        System.out.println("╭── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╮");
        System.out.println(memoria);
        System.out.println("╰── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╯\n");

        System.out.println( ANSI_YELLOW + " ╰┈➤  INFORMAÇÕES DOS DISCOS : \n " + ANSI_RESET);
        DiscoGrupo grupoDeDiscos = luquinhas.getGrupoDeDiscos();
        List<Disco> discos = grupoDeDiscos.getDiscos();
        System.out.println("╭── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╮");
        for (Disco disco : discos) {
            System.out.println(disco);
        }
        System.out.println("╰── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╯\n");


    }
}