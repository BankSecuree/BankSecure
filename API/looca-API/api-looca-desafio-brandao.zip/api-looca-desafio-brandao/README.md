# api-looca-desafio-brandao
Desafio do Brandão de criação das maquinas e inserção dos registros dos componentes corretos.
