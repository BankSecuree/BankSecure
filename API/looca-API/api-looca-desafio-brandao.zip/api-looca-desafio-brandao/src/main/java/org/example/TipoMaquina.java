package org.example;

public enum TipoMaquina {
    Servidor,
    CaixaEletronico,
}
