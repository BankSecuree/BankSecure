package org.example;


import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.servicos.ServicoGrupo;

import java.awt.*;

public class Main {

    public static final String ANSI_RESET = "\u001B[0m";

    public static final String ANSI_YELLOW = "\u001B[33m";

    public static void main(String[] args) {

        Looca luquitos = new Looca();

        // VARIAVEIS DE SERVIÇOS
//          String grupoServicos = luquitos.getGrupoDeServicos().getServicos().toString();
        String servicosAtivos = luquitos.getGrupoDeServicos().getServicosAtivos().toString();
        String servicosInativos = luquitos.getGrupoDeServicos().getServicosInativos().toString();
        Integer totalServicos = luquitos.getGrupoDeServicos().getTotalDeServicos();
        Integer totalServicosAtivos = luquitos.getGrupoDeServicos().getTotalServicosAtivos();
        Integer totalServicosInativos = luquitos.getGrupoDeServicos().getTotalServicosInativos();

        // VARIAVEIS DE PROCESSOS
        String grupoProcessos = luquitos.getGrupoDeProcessos().getProcessos().toString();
        Integer totalProcessos = luquitos.getGrupoDeProcessos().getTotalProcessos();
        Integer totalThreads = luquitos.getGrupoDeProcessos().getTotalThreads();

        // VARIAVEIS DE JANELAS
        String grupoJanelas = luquitos.getGrupoDeJanelas().getJanelas().toString();
        String janelasVisiveis = luquitos.getGrupoDeJanelas().getJanelasVisiveis().toString();
        Integer totalJanelas = luquitos.getGrupoDeJanelas().getTotalJanelas();
        Integer totalJanelasVisiveis = luquitos.getGrupoDeJanelas().getTotalJanelasVisiveis();


        // ============ SERVIÇOS ============

        // EXIBINDO OS SERVIÇOS ATIVOS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＳｅｒｖｉçｏｓ　Ａｔｉｖｏｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(servicosAtivos);

        // EXIBINDO OS SERVIÇO INATIVOS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＳｅｒｖｉçｏｓ　Ｉｎａｔｉｖｏｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(servicosInativos);

        // EXIBINDO O TOTAL DE SERVIÇOS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＴｏｔａｌ　ｄｅ　Ｓｅｒｖｉçｏｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(totalServicos);

        // EXIBINDO O TOTAL DE SERVIÇOS ATIVOS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＴｏｔａｌ　ｄｅ　Ｓｅｒｖｉçｏｓ　Ａｔｉｖｏｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(totalServicosAtivos);

        // EXIBINDO O TOTAL DE SERVIÇOS INATIVOS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＴｏｔａｌ　ｄｅ　Ｓｅｒｖｉçｏｓ　Ｉｎａｔｉｖｏｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(totalServicosInativos);


        // ============ PRCOCESSOS ============

        // EXIBINDO OS PROCESSOS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＰｒｏｃｅｓｓｏｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(grupoProcessos);

        // EXIBINDO O TOTAL DE PROCESSOS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＴｏｔａｌ　ｄｅ　Ｐｒｏｃｅｓｓｏｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(totalProcessos);

        // EXIBINDO O TOTAL DE THREADS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＴｏｔａｌ　ｄｅ　Ｔｈｒｅａｄｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(totalThreads);


        // ============ JANELAS ============

        // EXIBINDO AS JANELAS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＪａｎｅｌａｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(grupoJanelas);

        // EXIBINDO AS JANELAS VISIVEIS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＪａｎｅｌａｓ　Ｖｉｓｉｖｅｉｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(janelasVisiveis);

        // EXIBINDO O TOTAL DE JANELAS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＴｏｔａｌ　ｄｅ　Ｊａｎｅｌａｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(totalJanelas);

        // EXIBINDO O TOTAL DE JANELAS VISIVEIS
        System.out.println(ANSI_YELLOW + "\n>----------【\uFEFFＴｏｔａｌ　ｄｅ　Ｊａｎｅｌａｓ　Ｖｉｓｉｖｅｉｓ】----------<".toUpperCase() + ANSI_RESET);
        System.out.println(totalJanelasVisiveis);
    }
}