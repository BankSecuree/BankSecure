package org.example;

import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.processador.Processador;
import com.github.britooo.looca.api.group.temperatura.Temperatura;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Scanner;

public class Main {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String CYAN_BOLD_BRIGHT = "\033[1;96m";

    public static final String GREEN_BOLD_BRIGHT = "\033[1;92m";

    public static final String YELLOW_BOLD_BRIGHT = "\033[1;93m";

    public static final String WHITE_BOLD_BRIGHT = "\033[1;97m";
    public static final String PURPLE_BOLD_BRIGHT = "\033[1;95m";// PURPLE

    public static final String BLUE_BOLD_BRIGHT = "\033[1;94m";  // BLUE



    public static void main(String[] args) {

        Conexao conexao = new Conexao();
        JdbcTemplate con = conexao.getConexaoDoBanco();

        con.execute("USE bankSecure;");

        Looca luquinhas = new Looca();

        Scanner leitor = new Scanner(System.in);
        System.out.println( CYAN_BOLD_BRIGHT+ "₊❏❜ ⋮LISTA DE INFORMAÇÕES - PROJETO INDIVIDUAL ⌒" + ANSI_RESET);
        System.out.println( CYAN_BOLD_BRIGHT+ "by Danielle Yumi Munakata ⌒ \n" + ANSI_RESET);

        System.out.println( GREEN_BOLD_BRIGHT + "fkMaquinas disponíveis na agência Itaú Rudge Ramos :  \n 1 - MI-1 \n 2 - MI-2 \n 3 - MI-3 \n 4 - SI-1 \n" + ANSI_RESET);
        System.out.println( YELLOW_BOLD_BRIGHT + " > Escreva o fkMaquina ( NÚMEROS INTEIROS ): " + ANSI_RESET);
        int fkMaquina = leitor.nextInt();
        System.out.println( GREEN_BOLD_BRIGHT + " fkComponente disponíveis na agência Itaú Rudge Ramos : \n 1 - Temperatura  \n 2 -Uso " + ANSI_RESET);
        System.out.println( YELLOW_BOLD_BRIGHT + " > Escreva o fkComponente ( NÚMEROS INTEIROS ) : " + ANSI_RESET);
        int fkComponente = leitor.nextInt();

        while(true){

            System.out.println( CYAN_BOLD_BRIGHT + " ╰┈➤ INFORMAÇÔES DO PROCESSADOR: \n" + ANSI_RESET);
            Processador processador =  luquinhas.getProcessador();
            Temperatura temperatura = luquinhas.getTemperatura();

            Double temperaturaEscrita = temperatura.getTemperatura();
            double roundedUsoCPU = Math.round(processador.getUso());

            System.out.println( WHITE_BOLD_BRIGHT + "╭── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╮" + ANSI_RESET);
            System.out.println(PURPLE_BOLD_BRIGHT + "Uso do procesador: " + roundedUsoCPU + " %" + ANSI_RESET );
            System.out.println(BLUE_BOLD_BRIGHT + "Temperatura:" + temperaturaEscrita + "°C" + ANSI_RESET);
            System.out.println(WHITE_BOLD_BRIGHT + "╰── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╯\n" + ANSI_RESET);


            con.update("INSERT INTO registros(fkMaquina, fkComponente, valor, dataHora)VALUES (?,?,?,now())",
                    fkMaquina,fkComponente,temperaturaEscrita);

            con.update("INSERT INTO registros(fkMaquina, fkComponente, valor, dataHora)VALUES (?,?,?,now())",
                    fkMaquina,fkComponente,roundedUsoCPU);


            System.out.println( GREEN_BOLD_BRIGHT + "> Inserido no banco com sucesso!" + ANSI_RESET);

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


    }
}